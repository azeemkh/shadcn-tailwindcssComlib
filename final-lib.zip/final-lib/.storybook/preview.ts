import type { Preview } from '@storybook/react-vite'
import { withThemeByClassName } from '@storybook/addon-themes';
import '../src/styles/index.css';

const preview: Preview = {

  decorators: [
    withThemeByClassName({
      themes: {
        light: 'light',
        dark: 'dark',
        // brand: 'brand',
        // 'brand-dark': 'brand dark',
      },
      defaultTheme: 'light',
    }),
  ],

  parameters: {
    backgrounds: {
      default: 'light',
      values: [
        { name: 'light', value: '#ffffff' },
        { name: 'dark', value: '#020817' },
      ],
    },

    a11y: {
      // 'todo' - show a11y violations in the test UI only
      // 'error' - fail CI on a11y violations
      // 'off' - skip a11y checks entirely
      test: 'todo'
    }
  },

};

export default preview;