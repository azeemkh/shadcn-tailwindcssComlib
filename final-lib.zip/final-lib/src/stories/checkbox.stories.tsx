import type { Meta, StoryObj } from '@storybook/react';
import * as React from 'react';

import { Checkbox } from '../components/ui/checkbox';

const meta: Meta<typeof Checkbox> = {
  title: 'Components/ui/Checkbox',
  component: Checkbox,
  args: {
    disabled: false,
  },
  argTypes: {
    disabled: {
      control: 'boolean',
    },
    checked: {
      control: 'boolean',
    },
  },
};

export default meta;
type Story = StoryObj<typeof Checkbox>;


// -----------------------------
// Default (uncontrolled)
// -----------------------------
export const Default: Story = {
  render: (args) => (
    <Checkbox {...args} />
  ),
};

// -----------------------------
// Controlled Checkbox
// -----------------------------
export const Controlled: Story = {
  render: (args) => {
    const [checked, setChecked] = React.useState<boolean>(false);

    return (
      <Checkbox
        {...args}
        checked={checked}
        onCheckedChange={(value) => setChecked(!!value)}
      />
    );
  },
};

// -----------------------------
// Checked
// -----------------------------
export const Checked: Story = {
  args: {
    checked: true,
  },
};

// -----------------------------
// Disabled
// -----------------------------
export const Disabled: Story = {
  args: {
    disabled: true,
  },
};

// -----------------------------
// Checked + Disabled
// -----------------------------
export const CheckedDisabled: Story = {
  args: {
    checked: true,
    disabled: true,
  },
};

// -----------------------------
// With Label (common real usage)
// -----------------------------
export const WithLabel: Story = {
  render: (args) => (
    <label className="flex items-center gap-2 text-sm">
      <Checkbox {...args} />
      Accept terms and conditions
    </label>
  ),
};

// -----------------------------
// Multiple Checkboxes
// -----------------------------
export const Group = {
  render: () => (
    <div className="flex flex-col gap-2">
      <label className="flex items-center gap-2">
        <Checkbox defaultChecked />
        Option one
      </label>
      <label className="flex items-center gap-2">
        <Checkbox />
        Option two
      </label>
      <label className="flex items-center gap-2">
        <Checkbox disabled />
        Disabled option
      </label>
    </div>
  ),
};
