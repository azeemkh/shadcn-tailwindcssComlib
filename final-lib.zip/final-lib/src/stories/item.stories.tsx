import type { Meta, StoryObj } from '@storybook/react';

import {
  Item,
  ItemGroup,
  ItemSeparator,
  ItemMedia,
  ItemContent,
  ItemTitle,
  ItemDescription,
  ItemActions,
  ItemHeader,
  ItemFooter,
} from '../components/ui/item';

import { Button } from '../components/ui/button';
import { Mail, Star, Trash } from 'lucide-react';

const meta: Meta<typeof Item> = {
  title: 'Components/ui/Item',
  component: Item,
  argTypes: {
    variant: {
      control: 'select',
      options: ['default', 'outline', 'muted'],
    },
    size: {
      control: 'select',
      options: ['default', 'sm', 'xs'],
    },
  },
};

export default meta;
type Story = StoryObj<typeof Item>;


// --------------------------------
// Basic Item
// --------------------------------
export const Default: Story = {
  args: {
    variant: 'default',
    size: 'default',
  },
  render: (args) => (
    <Item {...args}>
      <ItemContent>
        <ItemTitle>Inbox</ItemTitle>
        <ItemDescription>
          All incoming messages
        </ItemDescription>
      </ItemContent>
    </Item>
  ),
};

// --------------------------------
// With Icon
// --------------------------------
export const WithIcon: Story = {
  render: () => (
    <Item>
      <ItemMedia variant="icon">
        <Mail />
      </ItemMedia>

      <ItemContent>
        <ItemTitle>Email</ItemTitle>
        <ItemDescription>
          Manage your email notifications
        </ItemDescription>
      </ItemContent>
    </Item>
  ),
};

// --------------------------------
// With Image
// --------------------------------
export const WithImage: Story = {
  render: () => (
    <Item>
      <ItemMedia variant="image">
        <img
          src="https://avatars.githubusercontent.com/u/9919?s=64"
          alt="Avatar"
        />
      </ItemMedia>

      <ItemContent>
        <ItemTitle>GitHub</ItemTitle>
        <ItemDescription>
          Connected GitHub account
        </ItemDescription>
      </ItemContent>
    </Item>
  ),
};

// --------------------------------
// With Actions
// --------------------------------
export const WithActions: Story = {
  render: () => (
    <Item>
      <ItemContent>
        <ItemTitle>Starred item</ItemTitle>
        <ItemDescription>
          You can take actions on this item
        </ItemDescription>
      </ItemContent>

      <ItemActions>
        <Button size="icon-xs" variant="ghost">
          <Star />
        </Button>
        <Button size="icon-xs" variant="ghost">
          <Trash />
        </Button>
      </ItemActions>
    </Item>
  ),
};

// --------------------------------
// Header + Footer
// --------------------------------
export const WithHeaderAndFooter: Story = {
  render: () => (
    <Item variant="outline">
      <ItemHeader>
        <ItemTitle>Project Alpha</ItemTitle>
        <span className="text-muted-foreground text-xs">
          Active
        </span>
      </ItemHeader>

      <ItemContent>
        <ItemDescription>
          Internal project with restricted access
        </ItemDescription>
      </ItemContent>

      <ItemFooter>
        <span className="text-muted-foreground text-xs">
          Updated 2 days ago
        </span>
        <Button size="xs" variant="ghost">
          Open
        </Button>
      </ItemFooter>
    </Item>
  ),
};

// --------------------------------
// Sizes
// --------------------------------
export const Sizes = {
  render: () => (
    <ItemGroup>
      <Item size="default">
        <ItemContent>
          <ItemTitle>Default size</ItemTitle>
        </ItemContent>
      </Item>

      <Item size="sm">
        <ItemContent>
          <ItemTitle>Small size</ItemTitle>
        </ItemContent>
      </Item>

      <Item size="xs">
        <ItemContent>
          <ItemTitle>Extra small</ItemTitle>
        </ItemContent>
      </Item>
    </ItemGroup>
  ),
};

// --------------------------------
// Grouped Items
// --------------------------------
export const Grouped = {
  render: () => (
    <ItemGroup>
      <Item>
        <ItemContent>
          <ItemTitle>Profile</ItemTitle>
          <ItemDescription>
            Manage your personal information
          </ItemDescription>
        </ItemContent>
      </Item>

      <ItemSeparator />

      <Item variant="muted">
        <ItemContent>
          <ItemTitle>Billing</ItemTitle>
          <ItemDescription>
            Payment methods and invoices
          </ItemDescription>
        </ItemContent>
      </Item>

      <ItemSeparator />

      <Item>
        <ItemContent>
          <ItemTitle>Security</ItemTitle>
          <ItemDescription>
            Passwords and 2FA
          </ItemDescription>
        </ItemContent>
      </Item>
    </ItemGroup>
  ),
};
