import type { Meta, StoryObj } from "@storybook/react"

import { Input } from "../components/ui/input"

const meta: Meta<typeof Input> = {
  title: "Components/ui/Input",
  component: Input,
  parameters: {
    layout: "centered",
  },
  argTypes: {
    type: {
      control: "select",
      options: ["text", "email", "password", "number", "search"],
    },
    disabled: {
      control: "boolean",
    },
    placeholder: {
      control: "text",
    },
    "aria-invalid": {
      control: "boolean",
    },
  },
}

export default meta
type Story = StoryObj<typeof Input>

export const Default: Story = {
  args: {
    type: "text",
    placeholder: "Type something…",
  },
  render: (args) => (
    <div className="w-64">
      <Input {...args} />
    </div>
  ),
}

export const Disabled: Story = {
  args: {
    type: "text",
    placeholder: "Disabled input",
    disabled: true,
  },
  render: (args) => (
    <div className="w-64">
      <Input {...args} />
    </div>
  ),
}

export const Invalid: Story = {
  args: {
    type: "text",
    placeholder: "Invalid input",
    "aria-invalid": true,
  },
  render: (args) => (
    <div className="w-64">
      <Input {...args} />
    </div>
  ),
}

export const Password: Story = {
  args: {
    type: "password",
    placeholder: "••••••••",
  },
  render: (args) => (
    <div className="w-64">
      <Input {...args} />
    </div>
  ),
}

export const FileInput: Story = {
  args: {
    type: "file",
  },
  render: (args) => (
    <div className="w-64">
      <Input {...args} />
    </div>
  ),
}
