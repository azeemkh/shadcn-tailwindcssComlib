import type { Meta, StoryObj } from '@storybook/react';

import {
  Avatar,
  AvatarImage,
  AvatarFallback,
  AvatarBadge,
  AvatarGroup,
  AvatarGroupCount,
} from '../components/ui/avatar';

const meta: Meta<typeof Avatar> = {
  title: 'Components/ui/Avatar',
  component: Avatar,
  argTypes: {
    size: {
      control: { type: 'select' },
      options: ['sm', 'default', 'lg'],
    },
  },
};

export default meta;
type Story = StoryObj<typeof Avatar>;


// -----------------------------
// Basic Avatar
// -----------------------------
export const Default: Story = {
  args: {
    size: 'default',
  },
  render: (args) => (
    <Avatar {...args}>
      <AvatarImage src="https://github.com/shadcn.png" alt="User avatar" />
      <AvatarFallback>JD</AvatarFallback>
    </Avatar>
  ),
};

// -----------------------------
// Sizes
// -----------------------------
export const Sizes = {
  render: () => (
    <div className="flex items-center gap-4">
      <Avatar size="sm">
        <AvatarFallback>SM</AvatarFallback>
      </Avatar>

      <Avatar size="default">
        <AvatarFallback>MD</AvatarFallback>
      </Avatar>

      <Avatar size="lg">
        <AvatarFallback>LG</AvatarFallback>
      </Avatar>
    </div>
  ),
};

// -----------------------------
// With Image Fallback
// -----------------------------
export const ImageFallback = {
  render: () => (
    <Avatar>
      <AvatarImage src="broken-url.jpg" alt="Broken image" />
      <AvatarFallback>NA</AvatarFallback>
    </Avatar>
  ),
};

// -----------------------------
// Avatar with Badge
// -----------------------------
export const WithBadge = {
  render: () => (
    <Avatar>
      <AvatarImage src="https://github.com/shadcn.png" />
      <AvatarFallback>AB</AvatarFallback>
      <AvatarBadge />
    </Avatar>
  ),
};

// -----------------------------
// Avatar Group
// -----------------------------
export const Group = {
  render: () => (
    <AvatarGroup>
      <Avatar>
        <AvatarImage src="https://github.com/shadcn.png" />
        <AvatarFallback>A</AvatarFallback>
      </Avatar>

      <Avatar>
        <AvatarImage src="https://github.com/shadcn.png" />
        <AvatarFallback>B</AvatarFallback>
      </Avatar>

      <Avatar>
        <AvatarImage src="https://github.com/shadcn.png" />
        <AvatarFallback>C</AvatarFallback>
      </Avatar>

      <AvatarGroupCount>+2</AvatarGroupCount>
    </AvatarGroup>
  ),
};

// -----------------------------
// Group Sizes
// -----------------------------
export const GroupSizes = {
  render: () => (
    <div className="flex flex-col gap-4">
      <AvatarGroup>
        <Avatar size="sm"><AvatarFallback>S</AvatarFallback></Avatar>
        <Avatar size="sm"><AvatarFallback>S</AvatarFallback></Avatar>
        <AvatarGroupCount>+1</AvatarGroupCount>
      </AvatarGroup>

      <AvatarGroup>
        <Avatar><AvatarFallback>M</AvatarFallback></Avatar>
        <Avatar><AvatarFallback>M</AvatarFallback></Avatar>
        <AvatarGroupCount>+2</AvatarGroupCount>
      </AvatarGroup>

      <AvatarGroup>
        <Avatar size="lg"><AvatarFallback>L</AvatarFallback></Avatar>
        <Avatar size="lg"><AvatarFallback>L</AvatarFallback></Avatar>
        <AvatarGroupCount>+3</AvatarGroupCount>
      </AvatarGroup>
    </div>
  ),
};
