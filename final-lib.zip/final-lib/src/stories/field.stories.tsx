import type { Meta, StoryObj } from '@storybook/react';

import {
  Field,
  FieldLabel,
  FieldDescription,
  FieldError,
  FieldGroup,
  FieldLegend,
  FieldSeparator,
  FieldSet,
  FieldContent,
} from '../components/ui/field';

import { Checkbox } from '../components/ui/checkbox';

const meta: Meta<typeof Field> = {
  title: 'Components/ui/Field',
  component: Field,
  argTypes: {
    orientation: {
      control: 'select',
      options: ['vertical', 'horizontal', 'responsive'],
    },
  },
};

export default meta;
type Story = StoryObj<typeof Field>;


// --------------------------------
// Basic Field
// --------------------------------
export const Default: Story = {
  args: {
    orientation: 'vertical',
  },
  render: (args) => (
    <Field {...args}>
      <FieldLabel>Email</FieldLabel>
      <FieldContent>
        <input
          type="email"
          placeholder="you@example.com"
          className="border-input bg-background focus-visible:ring-ring/50 focus-visible:ring-[3px] h-9 w-full rounded-md border px-3 outline-none"
        />
      </FieldContent>
    </Field>
  ),
};

// --------------------------------
// With Description
// --------------------------------
export const WithDescription: Story = {
  render: () => (
    <Field>
      <FieldLabel>Password</FieldLabel>
      <FieldContent>
        <input
          type="password"
          className="border-input bg-background h-9 w-full rounded-md border px-3"
        />
        <FieldDescription>
          Must be at least 8 characters long.
        </FieldDescription>
      </FieldContent>
    </Field>
  ),
};

// --------------------------------
// With Error
// --------------------------------
export const WithError: Story = {
  render: () => (
    <Field data-invalid="true">
      <FieldLabel>Email</FieldLabel>
      <FieldContent>
        <input
          type="email"
          className="border-input bg-background h-9 w-full rounded-md border px-3"
        />
        <FieldError errors={[{ message: 'Invalid email address' }]} />
      </FieldContent>
    </Field>
  ),
};

// --------------------------------
// Horizontal Layout
// --------------------------------
export const Horizontal: Story = {
  args: {
    orientation: 'horizontal',
  },
  render: (args) => (
    <Field {...args}>
      <FieldLabel>Username</FieldLabel>
      <FieldContent>
        <input
          className="border-input bg-background h-9 w-full rounded-md border px-3"
        />
      </FieldContent>
    </Field>
  ),
};

// --------------------------------
// Checkbox Field
// --------------------------------
export const CheckboxField: Story = {
  render: () => (
    <Field>
      <FieldLabel>
        <Checkbox defaultChecked />
        Accept terms
      </FieldLabel>
      <FieldDescription>
        You must accept before continuing.
      </FieldDescription>
    </Field>
  ),
};

// --------------------------------
// Field Group
// --------------------------------
export const GroupedFields = {
  render: () => (
    <FieldGroup>
      <Field>
        <FieldLabel>First name</FieldLabel>
        <FieldContent>
          <input className="border-input bg-background h-9 rounded-md border px-3" />
        </FieldContent>
      </Field>

      <Field>
        <FieldLabel>Last name</FieldLabel>
        <FieldContent>
          <input className="border-input bg-background h-9 rounded-md border px-3" />
        </FieldContent>
      </Field>
    </FieldGroup>
  ),
};

// --------------------------------
// Field Set + Legend
// --------------------------------
export const FieldSetExample = {
  render: () => (
    <FieldSet>
      <FieldLegend>Notification settings</FieldLegend>

      <Field>
        <FieldLabel>
          <Checkbox defaultChecked />
          Email notifications
        </FieldLabel>
      </Field>

      <Field>
        <FieldLabel>
          <Checkbox />
          SMS notifications
        </FieldLabel>
      </Field>
    </FieldSet>
  ),
};

// --------------------------------
// Separator
// --------------------------------
export const WithSeparator = {
  render: () => (
    <FieldGroup>
      <Field>
        <FieldLabel>Billing email</FieldLabel>
        <FieldContent>
          <input className="border-input bg-background h-9 rounded-md border px-3" />
        </FieldContent>
      </Field>

      <FieldSeparator>OR</FieldSeparator>

      <Field>
        <FieldLabel>Phone number</FieldLabel>
        <FieldContent>
          <input className="border-input bg-background h-9 rounded-md border px-3" />
        </FieldContent>
      </Field>
    </FieldGroup>
  ),
};
