import type { Meta, StoryObj } from "@storybook/react"
import {
  Alert,
  AlertTitle,
  AlertDescription,
} from "../components/ui/alert"
import { AlertTriangle, CheckCircle2 } from "lucide-react"

const meta: Meta<typeof Alert> = {
  title: "Components/ui/Alert",
  component: Alert,
  tags: ["autodocs"],
  argTypes: {
    variant: {
      control: "inline-radio",
      options: ["default", "destructive"],
    },
  },
}

export default meta
type Story = StoryObj<typeof Alert>

export const Default: Story = {
  args: {
    variant: "default",
  },
  render: (args) => (
    <Alert {...args}>
      <CheckCircle2 className="h-4 w-4" />
      <div>
        <AlertTitle>Success</AlertTitle>
        <AlertDescription>
          Your changes have been saved successfully.
        </AlertDescription>
      </div>
    </Alert>
  ),
}

export const Destructive: Story = {
  args: {
    variant: "destructive",
  },
  render: (args) => (
    <Alert {...args}>
      <AlertTriangle className="h-4 w-4" />
      <div>
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>
          Something went wrong. Please try again.
        </AlertDescription>
      </div>
    </Alert>
  ),
}

export const WithoutTitle: Story = {
  render: () => (
    <Alert>
      <AlertTriangle className="h-4 w-4" />
      <AlertDescription>
        This alert does not include a title, only a description.
      </AlertDescription>
    </Alert>
  ),
}

export const LongContent: Story = {
  render: () => (
    <Alert>
      <AlertTriangle className="h-4 w-4" />
      <div>
        <AlertTitle>Important Notice</AlertTitle>
        <AlertDescription>
          <p>
            This is a longer alert message intended to demonstrate how the
            component behaves when displaying more content. It supports
            multiple paragraphs and wraps correctly.
          </p>
          <p className="mt-2">
            Please read all instructions carefully before proceeding.
          </p>
        </AlertDescription>
      </div>
    </Alert>
  ),
}
