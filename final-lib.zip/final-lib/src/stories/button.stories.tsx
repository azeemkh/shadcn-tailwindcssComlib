import type { Meta, StoryObj } from '@storybook/react-vite';

import { fn } from 'storybook/test';

// import {action}  from '@storybook/addon-action'

import { Button } from '../components/ui/button';

// More on how to set up stories at: https://storybook.js.org/docs/writing-stories#default-export
const meta = {
  title: 'Components/ui/Button',
  component: Button,
  parameters: {
    // Optional parameter to center the component in the Canvas. More info: https://storybook.js.org/docs/configure/story-layout
    layout: 'centered',
  },
  // This component will have an automatically generated Autodocs entry: https://storybook.js.org/docs/writing-docs/autodocs
  tags: ['autodocs'],
  // More on argTypes: https://storybook.js.org/docs/api/argtypes
//   argTypes: {
//     backgroundColor: { control: 'color' },
//   },
//   // Use `fn` to spy on the onClick arg, which will appear in the actions panel once invoked: https://storybook.js.org/docs/essentials/actions#story-args
//   args: { onClick: fn() },
} satisfies Meta<typeof Button>;

export default meta;
type Story = StoryObj<typeof meta>;

// More on writing stories with args: https://storybook.js.org/docs/writing-stories/args
export const Default: Story = {
  args: {
    variant: 'default',
    size: 'default',
    disabled: false,
    onClick: fn(),
    children: "Default Button",
    className: "bg-primary text-primary-foreground hover:bg-primary/90"
  },
};

export const Destructive: Story = {
  args: {
    variant: 'destructive',
    size: 'lg',
    disabled: false,
    onClick: fn(),
    children: "Destructive Button",
    className: "dark:bg-red light:bg-red",
  },
};

export const Outline: Story = {
  args: {
    variant: 'outline',
    size: 'lg',
    disabled: false,
    onClick: fn(),
    children: "Outline Button",
    className: "border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50",
  },
};

export const Secondary: Story = {
  args: {
    variant: 'secondary',
    size: 'lg',
    disabled: false,
    onClick: fn(),
    children: "Secondary Button",
    className: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
  },
};

export const Ghost: Story = {
  args: {
    variant: 'ghost',
    size: 'lg',
    disabled: false,
    onClick: fn(),
    children: "Ghost Button",
    className: "hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",
  },
};


export const Link: Story = {
  args: {
    variant: 'link',
    size: 'lg',
    disabled: false,
    onClick: fn(),
    children: "Link Button",
    className: "text-primary underline-offset-4 hover:underline",
  },
};