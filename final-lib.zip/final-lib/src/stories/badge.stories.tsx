import type { Meta, StoryObj } from "@storybook/react"
import { Badge } from "../components/ui/badge"

const meta: Meta<typeof Badge> = {
  title: "Components/ui/Badge",
  component: Badge,
  tags: ["autodocs"],
  argTypes: {
    variant: {
      control: "select",
      options: [
        "default",
        "secondary",
        "destructive",
        "outline",
        "ghost",
        "link",
      ],
    },
    asChild: {
      control: "boolean",
    },
    children: {
      control: "text",
    },
  },
  args: {
    children: "Badge",
    variant: "default",
    asChild: false,
  },
}

export default meta
type Story = StoryObj<typeof Badge>

/* Playground */
export const Default: Story = {}

/* Variants */
export const Secondary: Story = {
  args: {
    variant: "secondary",
  },
}

export const Destructive: Story = {
  args: {
    variant: "destructive",
  },
}

export const Outline: Story = {
  args: {
    variant: "outline",
  },
}

export const Ghost: Story = {
  args: {
    variant: "ghost",
  },
}

export const Link: Story = {
  args: {
    variant: "link",
  },
}

/* asChild example */
export const AsLink: Story = {
  render: (args) => (
    <Badge {...args} asChild>
      <a href="#">Badge Link</a>
    </Badge>
  ),
}
