import type { Meta, StoryObj } from '@storybook/react';

import { Label } from '../components/ui/label';

const meta: Meta<typeof Label> = {
  title: 'Components/ui/Label',
  component: Label,
  args: {
    children: 'Label text',
  },
  argTypes: {
    children: {
      control: 'text',
    },
  },
};

export default meta;
type Story = StoryObj<typeof Label>;


// --------------------------------
// Default
// --------------------------------
export const Default: Story = {
  render: (args) => <Label {...args} />,
};

// --------------------------------
// With Input
// --------------------------------
export const WithInput: Story = {
  render: (args) => (
    <div className="flex flex-col gap-2">
      <Label htmlFor="email" {...args}>
        Email address
      </Label>
      <input
        id="email"
        type="email"
        placeholder="you@example.com"
        className="border-input bg-background h-9 rounded-md border px-3"
      />
    </div>
  ),
};

// --------------------------------
// Disabled (peer-disabled)
// --------------------------------
export const Disabled: Story = {
  render: () => (
    <div className="flex flex-col gap-2 group" data-disabled="true">
      <Label>Email</Label>
      <input
        disabled
        className="border-input bg-background h-9 rounded-md border px-3"
      />
    </div>
  ),
};

// --------------------------------
// Required Indicator
// --------------------------------
export const Required: Story = {
  render: () => (
    <Label>
      Username
      <span className="text-destructive">*</span>
    </Label>
  ),
};

// --------------------------------
// Checkbox Label
// --------------------------------
export const WithCheckbox: Story = {
  render: () => (
    <label className="flex items-center gap-2">
      <input type="checkbox" className="accent-primary" />
      <Label>Accept terms and conditions</Label>
    </label>
  ),
};
