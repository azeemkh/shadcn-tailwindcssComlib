import type { Meta, StoryObj } from "@storybook/react"

import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "../components/ui/accordion"

const meta: Meta<typeof Accordion> = {
  title: "Components/ui/Accordion",
  component: Accordion,
  parameters: {
    layout: "centered",
  },
  argTypes: {
    type: {
      control: "inline-radio",
      options: ["single", "multiple"],
    },
    collapsible: {
      control: "boolean",
    },
  },
}

export default meta
type Story = StoryObj<typeof Accordion>

function SampleItems() {
  return (
    <>
      <AccordionItem value="item-1">
        <AccordionTrigger>Is it accessible?</AccordionTrigger>
        <AccordionContent>
          Yes. It follows the WAI-ARIA accordion pattern and supports keyboard
          navigation.
        </AccordionContent>
      </AccordionItem>

      <AccordionItem value="item-2">
        <AccordionTrigger>Is it styled?</AccordionTrigger>
        <AccordionContent>
          It uses Tailwind CSS and Radix primitives for consistent styling and
          behavior.
        </AccordionContent>
      </AccordionItem>

      <AccordionItem value="item-3">
        <AccordionTrigger>Can I customize it?</AccordionTrigger>
        <AccordionContent>
          Absolutely. You can override styles, add icons, or nest any content
          inside.
        </AccordionContent>
      </AccordionItem>
    </>
  )
}

export const Single: Story = {
  args: {
    type: "single",
    collapsible: true,
  },
  render: (args) => (
    <div className="w-[420px]">
      <Accordion {...args}>
        <SampleItems />
      </Accordion>
    </div>
  ),
}

export const Multiple: Story = {
  args: {
    type: "multiple",
  },
  render: (args) => (
    <div className="w-[420px]">
      <Accordion {...args}>
        <SampleItems />
      </Accordion>
    </div>
  ),
}

export const DefaultOpen: Story = {
  render: () => (
    <div className="w-[420px]">
      <Accordion type="single" defaultValue="item-1" collapsible>
        <SampleItems />
      </Accordion>
    </div>
  ),
}
