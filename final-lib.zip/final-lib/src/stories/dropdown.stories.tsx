import type { Meta, StoryObj } from '@storybook/react';
import * as React from 'react';

import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuLabel,
  DropdownMenuShortcut,
  DropdownMenuCheckboxItem,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
} from '../components/ui/dropdown-menu';

const meta: Meta<typeof DropdownMenu> = {
  title: 'Components/ui/DropdownMenu',
  component: DropdownMenu,
};

export default meta;
type Story = StoryObj<typeof DropdownMenu>;


// --------------------------------
// Default
// --------------------------------
export const Default: Story = {
  render: () => (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className="bg-background hover:bg-muted border-input h-8 rounded-md border px-3 text-sm">
          Open menu
        </button>
      </DropdownMenuTrigger>

      <DropdownMenuContent>
        <DropdownMenuItem>
          New File
          <DropdownMenuShortcut>⌘N</DropdownMenuShortcut>
        </DropdownMenuItem>

        <DropdownMenuItem>
          Open…
          <DropdownMenuShortcut>⌘O</DropdownMenuShortcut>
        </DropdownMenuItem>

        <DropdownMenuSeparator />

        <DropdownMenuItem>Save</DropdownMenuItem>
        <DropdownMenuItem disabled>Save As…</DropdownMenuItem>

        <DropdownMenuSeparator />

        <DropdownMenuItem variant="destructive">
          Delete
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  ),
};

// --------------------------------
// Checkbox Items
// --------------------------------
export const WithCheckboxItems: Story = {
  render: () => {
    const [showLineNumbers, setShowLineNumbers] = React.useState(true);
    const [wrapLines, setWrapLines] = React.useState(false);

    return (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button className="bg-background hover:bg-muted border-input h-8 rounded-md border px-3 text-sm">
            View options
          </button>
        </DropdownMenuTrigger>

        <DropdownMenuContent>
          <DropdownMenuCheckboxItem
            checked={showLineNumbers}
            onCheckedChange={(v) => setShowLineNumbers(!!v)}
          >
            Show line numbers
          </DropdownMenuCheckboxItem>

          <DropdownMenuCheckboxItem
            checked={wrapLines}
            onCheckedChange={(v) => setWrapLines(!!v)}
          >
            Wrap lines
          </DropdownMenuCheckboxItem>
        </DropdownMenuContent>
      </DropdownMenu>
    );
  },
};

// --------------------------------
// Radio Group
// --------------------------------
export const WithRadioGroup: Story = {
  render: () => {
    const [theme, setTheme] = React.useState('system');

    return (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button className="bg-background hover:bg-muted border-input h-8 rounded-md border px-3 text-sm">
            Theme
          </button>
        </DropdownMenuTrigger>

        <DropdownMenuContent>
          <DropdownMenuLabel inset>Theme</DropdownMenuLabel>

          <DropdownMenuRadioGroup
            value={theme}
            onValueChange={setTheme}
          >
            <DropdownMenuRadioItem value="light">
              Light
            </DropdownMenuRadioItem>
            <DropdownMenuRadioItem value="dark">
              Dark
            </DropdownMenuRadioItem>
            <DropdownMenuRadioItem value="system">
              System
            </DropdownMenuRadioItem>
          </DropdownMenuRadioGroup>
        </DropdownMenuContent>
      </DropdownMenu>
    );
  },
};

// --------------------------------
// Sub Menu
// --------------------------------
export const WithSubMenu: Story = {
  render: () => (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className="bg-background hover:bg-muted border-input h-8 rounded-md border px-3 text-sm">
          Actions
        </button>
      </DropdownMenuTrigger>

      <DropdownMenuContent>
        <DropdownMenuItem>Edit</DropdownMenuItem>
        <DropdownMenuItem>Duplicate</DropdownMenuItem>

        <DropdownMenuSeparator />

        <DropdownMenuSub>
          <DropdownMenuSubTrigger inset>
            Share
          </DropdownMenuSubTrigger>

          <DropdownMenuSubContent>
            <DropdownMenuItem>Email</DropdownMenuItem>
            <DropdownMenuItem>Copy link</DropdownMenuItem>
            <DropdownMenuItem>Slack</DropdownMenuItem>
          </DropdownMenuSubContent>
        </DropdownMenuSub>
      </DropdownMenuContent>
    </DropdownMenu>
  ),
};

// --------------------------------
// Mixed (Realistic Example)
// --------------------------------
export const FullExample: Story = {
  render: () => {
    const [autoSave, setAutoSave] = React.useState(true);

    return (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button className="bg-background hover:bg-muted border-input h-8 rounded-md border px-3 text-sm">
            File
          </button>
        </DropdownMenuTrigger>

        <DropdownMenuContent>
          <DropdownMenuItem>
            New
            <DropdownMenuShortcut>⌘N</DropdownMenuShortcut>
          </DropdownMenuItem>

          <DropdownMenuItem>
            Open
            <DropdownMenuShortcut>⌘O</DropdownMenuShortcut>
          </DropdownMenuItem>

          <DropdownMenuSeparator />

          <DropdownMenuCheckboxItem
            checked={autoSave}
            onCheckedChange={(v) => setAutoSave(!!v)}
          >
            Auto save
          </DropdownMenuCheckboxItem>

          <DropdownMenuSeparator />

          <DropdownMenuSub>
            <DropdownMenuSubTrigger>
              Export
            </DropdownMenuSubTrigger>

            <DropdownMenuSubContent>
              <DropdownMenuItem>PDF</DropdownMenuItem>
              <DropdownMenuItem>Markdown</DropdownMenuItem>
              <DropdownMenuItem>HTML</DropdownMenuItem>
            </DropdownMenuSubContent>
          </DropdownMenuSub>

          <DropdownMenuSeparator />

          <DropdownMenuItem variant="destructive">
            Delete project
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    );
  },
};
