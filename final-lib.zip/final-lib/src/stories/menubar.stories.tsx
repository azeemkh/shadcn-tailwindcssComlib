import type { Meta, StoryObj } from '@storybook/react';
import * as React from 'react';

import {
  Menubar,
  MenubarMenu,
  MenubarTrigger,
  MenubarContent,
  MenubarItem,
  MenubarSeparator,
  MenubarLabel,
  MenubarShortcut,
  MenubarCheckboxItem,
  MenubarRadioGroup,
  MenubarRadioItem,
  MenubarSub,
  MenubarSubTrigger,
  MenubarSubContent,
} from '../components/ui/menubar';

const meta: Meta<typeof Menubar> = {
  title: 'Components/ui/Menubar',
  component: Menubar,
};

export default meta;
type Story = StoryObj<typeof Menubar>;


// --------------------------------
// Default Menubar
// --------------------------------
export const Default: Story = {
  render: () => {
    const [showStatusBar, setShowStatusBar] = React.useState(true);
    const [showActivityBar, setShowActivityBar] = React.useState(false);
    const [panelPosition, setPanelPosition] = React.useState('bottom');

    return (
      <Menubar>
        {/* File */}
        <MenubarMenu>
          <MenubarTrigger>File</MenubarTrigger>
          <MenubarContent>
            <MenubarItem>New Tab</MenubarItem>
            <MenubarItem>New Window</MenubarItem>
            <MenubarSeparator />
            <MenubarItem>Open File</MenubarItem>
            <MenubarItem disabled>Open Folder</MenubarItem>
            <MenubarSeparator />
            <MenubarItem variant="destructive">Close</MenubarItem>
          </MenubarContent>
        </MenubarMenu>

        {/* Edit */}
        <MenubarMenu>
          <MenubarTrigger>Edit</MenubarTrigger>
          <MenubarContent>
            <MenubarItem>
              Undo <MenubarShortcut>⌘Z</MenubarShortcut>
            </MenubarItem>
            <MenubarItem>
              Redo <MenubarShortcut>⇧⌘Z</MenubarShortcut>
            </MenubarItem>
            <MenubarSeparator />
            <MenubarItem>Cut</MenubarItem>
            <MenubarItem>Copy</MenubarItem>
            <MenubarItem>Paste</MenubarItem>
          </MenubarContent>
        </MenubarMenu>

        {/* View */}
        <MenubarMenu>
          <MenubarTrigger>View</MenubarTrigger>
          <MenubarContent>
            <MenubarCheckboxItem
              checked={showStatusBar}
              onCheckedChange={(v) => setShowStatusBar(!!v)}
            >
              Status Bar
            </MenubarCheckboxItem>

            <MenubarCheckboxItem
              checked={showActivityBar}
              onCheckedChange={(v) => setShowActivityBar(!!v)}
            >
              Activity Bar
            </MenubarCheckboxItem>

            <MenubarSeparator />

            <MenubarLabel inset>Panel position</MenubarLabel>
            <MenubarRadioGroup
              value={panelPosition}
              onValueChange={setPanelPosition}
            >
              <MenubarRadioItem value="bottom">
                Bottom
              </MenubarRadioItem>
              <MenubarRadioItem value="right">
                Right
              </MenubarRadioItem>
            </MenubarRadioGroup>
          </MenubarContent>
        </MenubarMenu>

        {/* Help */}
        <MenubarMenu>
          <MenubarTrigger>Help</MenubarTrigger>
          <MenubarContent>
            <MenubarItem>Documentation</MenubarItem>
            <MenubarItem>Release Notes</MenubarItem>

            <MenubarSeparator />

            <MenubarSub>
              <MenubarSubTrigger inset>
                More
              </MenubarSubTrigger>
              <MenubarSubContent>
                <MenubarItem>About</MenubarItem>
                <MenubarItem>Settings</MenubarItem>
              </MenubarSubContent>
            </MenubarSub>
          </MenubarContent>
        </MenubarMenu>
      </Menubar>
    );
  },
};
