import type { Meta, StoryObj } from '@storybook/react';

import { Separator } from '../components/ui/separator';

const meta: Meta<typeof Separator> = {
  title: 'Components/ui/Separator',
  component: Separator,
  argTypes: {
    orientation: {
      control: 'radio',
      options: ['horizontal', 'vertical'],
    },
    decorative: {
      control: 'boolean',
    },
  },
};

export default meta;
type Story = StoryObj<typeof Separator>;


// --------------------------------
// Default (Horizontal)
// --------------------------------
export const Default: Story = {
  args: {
    orientation: 'horizontal',
  },
  render: (args) => (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">Above</p>
      <Separator {...args} />
      <p className="text-sm text-muted-foreground">Below</p>
    </div>
  ),
};

// --------------------------------
// Vertical
// --------------------------------
export const Vertical: Story = {
  args: {
    orientation: 'vertical',
  },
  render: (args) => (
    <div className="flex h-10 items-center gap-4">
      <span className="text-sm">Left</span>
      <Separator {...args} />
      <span className="text-sm">Right</span>
    </div>
  ),
};

// --------------------------------
// Non-decorative (ARIA visible)
// --------------------------------
export const NonDecorative: Story = {
  args: {
    decorative: false,
  },
  render: (args) => (
    <div className="space-y-2">
      <p className="text-sm">Section one</p>
      <Separator {...args} />
      <p className="text-sm">Section two</p>
    </div>
  ),
};
