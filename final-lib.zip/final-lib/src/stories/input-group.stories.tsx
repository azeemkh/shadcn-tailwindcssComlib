import type { Meta, StoryObj } from '@storybook/react';

import {
  InputGroup,
  InputGroupAddon,
  InputGroupButton,
  InputGroupText,
  InputGroupInput,
  InputGroupTextarea,
} from '../components/ui/input-group'

import { Search, Eye, Mail } from 'lucide-react';

const meta: Meta<typeof InputGroup> = {
  title: 'Components/ui/InputGroup',
  component: InputGroup,
};

export default meta;
type Story = StoryObj<typeof InputGroup>;


// --------------------------------
// Basic (Addon + Input)
// --------------------------------
export const Default: Story = {
  render: () => (
    <InputGroup className="max-w-sm">
      <InputGroupAddon>
        <Search />
      </InputGroupAddon>
      <InputGroupInput placeholder="Search…" />
    </InputGroup>
  ),
};

// --------------------------------
// Inline End Addon
// --------------------------------
export const InlineEndAddon: Story = {
  render: () => (
    <InputGroup className="max-w-sm">
      <InputGroupInput placeholder="Email address" />
      <InputGroupAddon align="inline-end">
        <Mail />
      </InputGroupAddon>
    </InputGroup>
  ),
};

// --------------------------------
// With Button
// --------------------------------
export const WithButton: Story = {
  render: () => (
    <InputGroup className="max-w-sm">
      <InputGroupInput placeholder="Password" type="password" />
      <InputGroupButton aria-label="Toggle visibility">
        <Eye />
      </InputGroupButton>
    </InputGroup>
  ),
};

// --------------------------------
// Text Addon
// --------------------------------
export const TextAddon: Story = {
  render: () => (
    <InputGroup className="max-w-sm">
      <InputGroupText>https://</InputGroupText>
      <InputGroupInput placeholder="example.com" />
    </InputGroup>
  ),
};

// --------------------------------
// Block Start Addon
// --------------------------------
export const BlockStartAddon: Story = {
  render: () => (
    <InputGroup className="max-w-sm">
      <InputGroupAddon align="block-start">
        Username
      </InputGroupAddon>
      <InputGroupInput placeholder="john.doe" />
    </InputGroup>
  ),
};

// --------------------------------
// Block End Addon
// --------------------------------
export const BlockEndAddon: Story = {
  render: () => (
    <InputGroup className="max-w-sm">
      <InputGroupInput placeholder="Message" />
      <InputGroupAddon align="block-end">
        Press Enter to send
      </InputGroupAddon>
    </InputGroup>
  ),
};

// --------------------------------
// Textarea
// --------------------------------
export const WithTextarea: Story = {
  render: () => (
    <InputGroup className="max-w-md">
      <InputGroupAddon align="block-start">
        Message
      </InputGroupAddon>
      <InputGroupTextarea placeholder="Write your message…" />
    </InputGroup>
  ),
};

// --------------------------------
// Invalid State
// --------------------------------
export const Invalid: Story = {
  render: () => (
    <InputGroup className="max-w-sm">
      <InputGroupAddon>
        <Mail />
      </InputGroupAddon>
      <InputGroupInput
        aria-invalid="true"
        placeholder="Invalid email"
      />
    </InputGroup>
  ),
};

// --------------------------------
// Disabled
// --------------------------------
export const Disabled: Story = {
  render: () => (
    <InputGroup className="max-w-sm" data-disabled="true">
      <InputGroupAddon>
        <Search />
      </InputGroupAddon>
      <InputGroupInput disabled placeholder="Disabled input" />
    </InputGroup>
  ),
};
