import type { Meta, StoryObj } from '@storybook/react';
import * as React from 'react';

import { Textarea } from '../components/ui/textarea';

const meta: Meta<typeof Textarea> = {
  title: 'Components/ui/Textarea',
  component: Textarea,
  args: {
    placeholder: 'Type your message here…',
    disabled: false,
  },
  argTypes: {
    disabled: {
      control: 'boolean',
    },
    placeholder: {
      control: 'text',
    },
  },
};

export default meta;
type Story = StoryObj<typeof Textarea>;


// --------------------------------
// Default
// --------------------------------
export const Default: Story = {
  render: (args) => <Textarea {...args} />,
};

// --------------------------------
// With Value (Controlled)
// --------------------------------
export const Controlled: Story = {
  render: (args) => {
    const [value, setValue] = React.useState(
      'This is a controlled textarea.\nYou can edit this text.'
    );

    return (
      <Textarea
        {...args}
        value={value}
        onChange={(e) => setValue(e.target.value)}
      />
    );
  },
};

// --------------------------------
// Disabled
// --------------------------------
export const Disabled: Story = {
  args: {
    disabled: true,
    placeholder: 'Textarea is disabled',
  },
};

// --------------------------------
// Invalid (Error State)
// --------------------------------
export const Invalid: Story = {
  render: () => (
    <Textarea
      aria-invalid="true"
      placeholder="This field has an error"
    />
  ),
};

// --------------------------------
// With Label + Description
// --------------------------------
export const WithLabel: Story = {
  render: () => (
    <div className="flex flex-col gap-2 max-w-md">
      <label className="text-sm font-medium">
        Message
      </label>
      <Textarea placeholder="Write your message…" />
      <p className="text-muted-foreground text-sm">
        Max 500 characters.
      </p>
    </div>
  ),
};
