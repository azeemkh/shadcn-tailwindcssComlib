import type { Meta, StoryObj } from '@storybook/react';
import * as React from 'react';

import {
  Drawer,
  DrawerTrigger,
  DrawerClose,
  DrawerContent,
  DrawerHeader,
  DrawerFooter,
  DrawerTitle,
  DrawerDescription,
} from '../components/ui/drawer';

import { Button } from '../components/ui/button';

const meta: Meta<typeof Drawer> = {
  title: 'Components/ui/Drawer',
  component: Drawer,
};

export default meta;
type Story = StoryObj<typeof Drawer>;


// --------------------------------
// Basic (Bottom Drawer)
// --------------------------------
export const Default: Story = {
  render: () => (
    <Drawer>
      <DrawerTrigger asChild>
        <Button>Open drawer</Button>
      </DrawerTrigger>

      <DrawerContent>
        <DrawerHeader>
          <DrawerTitle>Drawer title</DrawerTitle>
          <DrawerDescription>
            This is a basic bottom drawer.
          </DrawerDescription>
        </DrawerHeader>

        <div className="px-4 py-2">
          <p className="text-sm">
            You can put any content here.
          </p>
        </div>

        <DrawerFooter>
          <DrawerClose asChild>
            <Button variant="outline">Cancel</Button>
          </DrawerClose>
          <DrawerClose asChild>
            <Button>Confirm</Button>
          </DrawerClose>
        </DrawerFooter>
      </DrawerContent>
    </Drawer>
  ),
};

// --------------------------------
// Controlled Drawer
// --------------------------------
export const Controlled: Story = {
  render: () => {
    const [open, setOpen] = React.useState(false);

    return (
      <>
        <Button onClick={() => setOpen(true)}>
          Open controlled drawer
        </Button>

        <Drawer open={open} onOpenChange={setOpen}>
          <DrawerContent>
            <DrawerHeader>
              <DrawerTitle>Controlled drawer</DrawerTitle>
              <DrawerDescription>
                Open state is managed externally.
              </DrawerDescription>
            </DrawerHeader>

            <DrawerFooter>
              <Button variant="outline" onClick={() => setOpen(false)}>
                Close
              </Button>
            </DrawerFooter>
          </DrawerContent>
        </Drawer>
      </>
    );
  },
};

// --------------------------------
// Left Drawer
// --------------------------------
export const Left: Story = {
  render: () => (
    <Drawer direction="left">
      <DrawerTrigger asChild>
        <Button>Open left drawer</Button>
      </DrawerTrigger>

      <DrawerContent>
        <DrawerHeader>
          <DrawerTitle>Navigation</DrawerTitle>
          <DrawerDescription>
            This drawer slides in from the left.
          </DrawerDescription>
        </DrawerHeader>

        <div className="px-4 space-y-2 text-sm">
          <p>Dashboard</p>
          <p>Projects</p>
          <p>Settings</p>
        </div>

        <DrawerFooter>
          <DrawerClose asChild>
            <Button variant="outline">Close</Button>
          </DrawerClose>
        </DrawerFooter>
      </DrawerContent>
    </Drawer>
  ),
};

// --------------------------------
// Right Drawer
// --------------------------------
export const Right: Story = {
  render: () => (
    <Drawer direction="right">
      <DrawerTrigger asChild>
        <Button>Open right drawer</Button>
      </DrawerTrigger>

      <DrawerContent>
        <DrawerHeader>
          <DrawerTitle>Details</DrawerTitle>
          <DrawerDescription>
            Supplemental information panel.
          </DrawerDescription>
        </DrawerHeader>

        <div className="px-4 py-2 text-sm">
          This drawer is useful for inspectors or settings.
        </div>

        <DrawerFooter>
          <DrawerClose asChild>
            <Button>Done</Button>
          </DrawerClose>
        </DrawerFooter>
      </DrawerContent>
    </Drawer>
  ),
};

// --------------------------------
// Top Drawer
// --------------------------------
export const Top: Story = {
  render: () => (
    <Drawer direction="top">
      <DrawerTrigger asChild>
        <Button>Open top drawer</Button>
      </DrawerTrigger>

      <DrawerContent>
        <DrawerHeader>
          <DrawerTitle>Quick actions</DrawerTitle>
          <DrawerDescription>
            Slides down from the top.
          </DrawerDescription>
        </DrawerHeader>

        <DrawerFooter>
          <DrawerClose asChild>
            <Button variant="outline">Close</Button>
          </DrawerClose>
        </DrawerFooter>
      </DrawerContent>
    </Drawer>
  ),
};
