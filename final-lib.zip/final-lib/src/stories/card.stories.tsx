import type { Meta, StoryObj } from "@storybook/react"

import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardAction,
  CardContent,
  CardFooter,
} from "../components/ui/card"

const meta: Meta<typeof Card> = {
  title: "Components/ui/Card",
  component: Card,
  parameters: {
    layout: "centered",
  },
  argTypes: {
    size: {
      control: "inline-radio",
      options: ["default", "sm"],
    },
  },
}

export default meta
type Story = StoryObj<typeof Card>

export const Default: Story = {
  args: {
    size: "default",
  },
  render: (args) => (
    <div className="w-[420px]">
      <Card {...args}>
        <CardHeader className="border-b">
          <div>
            <CardTitle>Card title</CardTitle>
            <CardDescription>
              Card description goes here and can span multiple lines.
            </CardDescription>
          </div>
          <CardAction>
            <button className="text-sm text-muted-foreground hover:text-foreground">
              Action
            </button>
          </CardAction>
        </CardHeader>

        <CardContent>
          <p>
            This is the main content area of the card. You can place text,
            forms, media, or any custom layout here.
          </p>
        </CardContent>

        <CardFooter>
          <span className="text-muted-foreground text-sm">
            Footer content
          </span>
        </CardFooter>
      </Card>
    </div>
  ),
}

export const Small: Story = {
  args: {
    size: "sm",
  },
  render: (args) => (
    <div className="w-[360px]">
      <Card {...args}>
        <CardHeader className="border-b">
          <CardTitle>Small card</CardTitle>
          <CardDescription>
            Compact variant with reduced padding.
          </CardDescription>
        </CardHeader>

        <CardContent>
          <p>
            This version is useful for dense layouts or side panels.
          </p>
        </CardContent>

        <CardFooter>
          <span className="text-muted-foreground text-sm">
            Footer
          </span>
        </CardFooter>
      </Card>
    </div>
  ),
}

export const WithoutFooter: Story = {
  render: () => (
    <div className="w-[420px]">
      <Card>
        <CardHeader className="border-b">
          <CardTitle>No footer</CardTitle>
          <CardDescription>
            Cards automatically adjust spacing when the footer is missing.
          </CardDescription>
        </CardHeader>

        <CardContent>
          <p>
            The bottom padding remains consistent thanks to your
            <code className="mx-1 rounded bg-muted px-1 py-0.5 text-xs">
              has-data
            </code>
            selectors.
          </p>
        </CardContent>
      </Card>
    </div>
  ),
}
