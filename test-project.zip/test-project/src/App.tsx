import { useState } from 'react'
// import {Button, Input, Avatar, AvatarFallback, AvatarImage } from 'my-project-lab-1'
// import './index.css'
// import 'my-project-lab-1/dist/style.css';
import { Button, Input, Avatar, AvatarImage, AvatarFallback  } from 'app-vite-tailwindcssfour';
import 'app-vite-tailwindcssfour/dist/style.css';

export default function App() {
  const [mode, setMode] = useState('light');

  const toggleDarkMode = () => {
    setMode(mode === 'light' ? 'dark' : 'light');
  };

  return (
    <div className={`flex align-center justify-start ${mode} flex-col h-[100vh]`}>
      <h1 className="text-3xl font-bold underline text-center p-4">
        tailwindcssV4 + shadcn-ui-library + vite
      </h1>
      <div className='py-4 text-center'>
        <Button onClick={toggleDarkMode}>Toggle Dark Mode</Button>
      </div>
      <div className='py-4 text-center'>
        <Button variant="destructive">Shadcn Button</Button>
      </div>
      <div className='align-center justify-center py-4 w-80 mx-auto'>
        <Input
          id="input-field-username"
          type="text"
          placeholder="Enter your username"
          className='text-center'
        />
      </div>
      <div className='text-center mx-auto'>
        <Avatar>
        <AvatarImage src="https://github.com/shadcn.png" />
        <AvatarFallback>CN</AvatarFallback>
      </Avatar>
      </div>
      
      {/* <div className='py-4'>
        <Alert>
          <Terminal className="h-4 w-4" />
          <AlertTitle>Heads up!</AlertTitle>
          <AlertDescription>
            You can add components and dependencies to your app using the cli.
          </AlertDescription>
        </Alert>
      </div> */}
    </div>
  )
}


